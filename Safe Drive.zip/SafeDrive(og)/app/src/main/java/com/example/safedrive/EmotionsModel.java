package com.example.safedrive;

public class EmotionsModel {

    private String emotion;
    private long detected;
    private EmotionsModel() {}

    private EmotionsModel(String emotion, long detected) {
        this.emotion = emotion;
        this.detected = detected;
    }

    public String getEmotion() {
        return emotion;
    }

    public void setEmotion(String emotion) {
        this.emotion = emotion;
    }


    public long getDetected() {
        return detected;
    }

    public void setDetected(long detected) {
        this.detected = detected;
    }


}
