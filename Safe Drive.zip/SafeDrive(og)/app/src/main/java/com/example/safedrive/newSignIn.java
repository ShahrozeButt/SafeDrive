package com.example.safedrive;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.firebase.ui.firestore.FirestoreRecyclerAdapter;
import com.firebase.ui.firestore.FirestoreRecyclerOptions;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.Query;

public class newSignIn extends AppCompatActivity {

    private FirebaseFirestore firebaseFirestore;
    private RecyclerView mFireStoreList;
    private FirestoreRecyclerAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_new_sign_in);

        firebaseFirestore = FirebaseFirestore.getInstance();
        mFireStoreList = findViewById(R.id.firestore_list);

        //Query
        Query query = firebaseFirestore.collection("users");
        //RecyclerOptions
        FirestoreRecyclerOptions<EmotionsModel> options = new FirestoreRecyclerOptions.Builder<EmotionsModel>().setQuery(query, EmotionsModel.class).build();

        adapter = new FirestoreRecyclerAdapter<EmotionsModel, EmotionsViewHolder>(options) {
            @NonNull
            @Override
            public EmotionsViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
                View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.list_emotion_single, parent, false);
                return new EmotionsViewHolder(view);
            }

            @Override
            protected void onBindViewHolder(@NonNull EmotionsViewHolder holder, int position, @NonNull EmotionsModel model) {
                holder.list_emotion.setText(model.getEmotion());
                holder.list_detected.setText(model.getDetected() + "");
            }
        };

        mFireStoreList.setHasFixedSize(true);
        mFireStoreList.setLayoutManager(new LinearLayoutManager(this));
        mFireStoreList.setAdapter(adapter);

    }

    private class EmotionsViewHolder extends RecyclerView.ViewHolder {

        private TextView list_emotion;
        private TextView list_detected;

        public EmotionsViewHolder(@NonNull View itemView) {
            super((itemView));

            list_emotion = itemView.findViewById(R.id.list_emotion);
            list_detected = itemView.findViewById(R.id.list_detected);

        }
    }

    @Override
    protected void onStop() {
        super.onStop();
        adapter.stopListening();
    }

    @Override
    protected void onStart() {
        super.onStart();
        adapter.startListening();
    }
}
